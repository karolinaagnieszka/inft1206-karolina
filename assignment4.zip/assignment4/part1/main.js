// Name: Karolina Blok
// File: assignment4
// Date: 10 Apri 2026
// this file goes through fundamentals of JavaScript



// Complete variable definitions and random functions

const customName = document.getElementById("custom-name");
const generateBtn = document.querySelector(".generate");
const story = document.querySelector(".story");

function randomValueFromArray(array) {
  const random = Math.floor(Math.random() * array.length);
  return array[random];
}

// Raw text strings
const storyText = `It was 94 Fahrenheit outside, so :insertx: went for a walk. When 
they got to :inserty:, they stared in horror for a few moments, then :insertz:. 
Bob saw the whole thing, but was not surprised — :insertx: weighs 300 pounds, and it was a hot day.`;

const insertX = ["Willy the Goblin", "Big Daddy", "Father Christmas"];
const insertY = ["the soup kitchen", "Disneyland", "the White House"];
const insertZ = ["spontaneously combusted", "melted into a puddle on the sidewalk",
"turned into a slug and slithered away"];


// Partial return random string function

function result() {
  let newStory = storyText;

  const xitem = randomValueFromArray(insertX);
  const yitem = randomValueFromArray(insertY);
  const zitem = randomValueFromArray(insertZ);


  newStory = newStory.replaceAll(":insertx:", xitem);
  newStory = newStory.replaceAll(":inserty:", yitem);
  newStory = newStory.replaceAll(":insertz:", zitem);


  if (customName.value !== "") {
    const name = customName.value;
    newStory = newStory.replaceAll("Bob", name);
  }

  if (document.getElementById("uk").checked) {
    const weight = `${Math.round(300 / 14)} stone`;
    const temperature = `${Math.round((94 - 32) * 5 / 9)} centigrade`;

    newStory = newStory.replaceAll("300 pounds", weight);
    newStory = newStory.replaceAll("94 Fahrenheit", temperature);
  }

  // TODO: replace "" with the correct expression
  story.textContent = newStory;
  story.style.visibility = "visible";
}

generateBtn.addEventListener("click", result);